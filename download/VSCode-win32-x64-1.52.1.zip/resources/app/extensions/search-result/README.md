# Language Features for Search Result files

**Notice:** This extension is bundled with Visual Studio Code. It can be disabled but not uninstalled.

This extension provides Syntax Highlighting, Symbol Information, Result Highlighting, and Go to Definition capabilities for the Search Results Editor.
