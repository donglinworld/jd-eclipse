# VSCode JSHint extension - server part

The server part of the VSCode jshint extension.